

public class StringPrinter
{
   public static void main(String[] args)
   {
      String word = "separate"; 
      
      System.out.println(3 * word.length());
      
      System.out.println(word.toUpperCase());
      System.out.println(word.replace("r", "12").replace("a", "4").replace("e", "3"));
      System.out.println(word);
   }
}

