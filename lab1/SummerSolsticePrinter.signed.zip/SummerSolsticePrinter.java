public class SummerSolsticePrinter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Day today = new Day();
		System.out.println(today);
		
		Day  SummerSolstice = new Day(2017, 6, 20);
		System.out.println(SummerSolstice.daysFrom(today));

	}

}