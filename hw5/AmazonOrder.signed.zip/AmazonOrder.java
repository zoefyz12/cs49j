

/**
 * AmazonOrder is a class which keeps track of the items a person orders on Amazon
 * @author Fangyi Zhao
 *
 */
public class AmazonOrder {
	
	public static final double TAX = 8.5;
	private String contents;
	private double subtotal;
	
	/**
	 * Construct a default Construct a default constructor of the subtotal and contents to make sure they are 
	 * zero and initialized.
	 */
	public AmazonOrder()
	{
		subtotal = 0;
		contents  = "";
	}
	/**
	 * This is the add method adds this cost to the subtotal 
	 * for this AmazonOrder and records the item added in the contents.
	 * @param cost the cost of the added item
	 */
	
	public void add(double cost)
	{
		subtotal += cost;
		contents += "Add Item: " + String.valueOf(cost) + '\n';
	}

	/**
	 * This is the remove method that subtracts this cost from the subtotal for this AmazonOrder 
	 * and records the item removed in the contents.
	 * @param cost the cost of the subtract item
	 */
	public void remove(double cost)
	{
		subtotal -= cost;
		contents += "Remove Item: " + String.valueOf(cost) + '\n';
	}
	
	/**
	 * This is the get subtotal method that gets the subtotal for this AmazonOrder.
	 * @return The subtotal will be returned.
	 */
	public double getSubtotal()
	{
		return subtotal;
	}
	
	/**
	 * This is the get total method that gets the total which is the subtotal plus tax.
	 * @return The total cost will be returned.
	 */
	public double getTotal()
	{
		return subtotal * TAX * 0.01 + subtotal;
	}
	
	/**
	 * This is the get content method that gets
	 * the cost of the items added to and removed from in the order and the total cost.
	 * @return The content will be returned.
	 */
	public String getContents()
	{
		if (!contents.contains("Total"))
			contents += "Total: " + String.valueOf(getTotal()) + '\n';
		
		return contents;
	}
	/**
	 * This method returns the object to its original state where no items are in the order.
	 */
	
	public void reset()
	{
		subtotal = 0;
		contents = "";
	}
}
