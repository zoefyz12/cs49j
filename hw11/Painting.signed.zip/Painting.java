
/**
 * Implement a subclass of Product called Painting.
 * @author Fangyi Zhao
 *
 */
public class Painting extends Product {
	
	private String artist;
	/**
	 * This painting constructor has a String instance variable, artist, in addition to description and price.
	 * @param desc The description of the product.
	 * @param price The price of the product.
	 * @param art The artist of the product.
	 */
	public Painting(String desc, double price, String art)
	{
		super(desc,price);
		artist = art;
	}
	/**
	 * This method helps get the artist of the product.
	 * @return The artist has been returned.
	 */
	public String getArtist()
	{
		return artist;
	}
	/**
	 * This method returns true if the books have the same author otherwise false.
	 * @param other The other product.
	 * @return Return true or false.
	 */
	public boolean sameAuthor(Painting other)
	{
		if (artist.equals(other.getArtist()))
		{
			return true;
		}
		return false;
	}
	/**
	 * This method helps get the description and artist.
	 * @return Return the description of the product.
	 */
	@Override
	public String getDescription()
	{
		return super.getDescription() + " " + artist;
	}

}
