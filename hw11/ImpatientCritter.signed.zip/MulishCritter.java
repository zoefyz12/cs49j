
/**
 * This class is a subclass of critter which names MulishCritter.
 * @author Fangyi Zhao
 *
 */
public class MulishCritter extends Critter{
	
private int counter;
	/**
	 * This constructor take the weight as parameter and set counter to initial.
	 * @param theWeight The weight of the critter.
	 */
	public MulishCritter(double theWeight) {
		super(theWeight);
		counter = 0;
	}
	/**
	 * This method tells that mulish critter only moves every third time you tell it move.
	 * @param steps Get the steps of the critter.
	 */
	@Override
	public void move(int steps)
	{
		if (counter % 3 == 0)
		{
			super.move(steps);
		}
		
		counter++;
	}
	

}
