
/**
 * This class is a subclass of critter which names LethargicCritter.
 * @author Fangyi Zhao
 *
 */
public class LethargicCritter extends Critter{
	
	private boolean eat;
	/**
	 * This constructor take the weight as parameter and set eat as true.
	 * @param theWeight The weight of the critter.
	 */
	public LethargicCritter(double theWeight) {
		super(theWeight);
		eat = true;
	}
	/**
	 * This method helps calculate the history of the lethargic critter and it will either eat or sleep. 
	 * @param steps Get the steps of the critter.
	 */
	@Override
	public void move (int steps)
	{
		if (eat)
		{
			super.addHistory("eat");
			eat = false;
		}
		else
		{
			super.addHistory("sleep");
			eat = true;
		}
	}
	

}
