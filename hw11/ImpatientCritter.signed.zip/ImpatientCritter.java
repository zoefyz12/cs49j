
/**
 * This class is a subclass of critter.
 * @author Fangyi Zhao
 *
 */
public class ImpatientCritter extends Critter{
	/**
	 * The constructor take the weight as parameter.
	 * @param theWeight The weight of the critter.
	 */
	public ImpatientCritter(double theWeight) 
	{
		super(theWeight);
	}
	/**
	 * This method helps calculate the steps which means the real move is two times steps.
	 * @param steps Return the steps of the critter. 
	 */
	@Override
	public void move(int steps)
	{
		super.move(steps * 2);
	}
}

