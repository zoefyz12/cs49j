
/**
 * This account is a subclass of BankAccount which named transaction account.
 * @author Fangyi Zhao
 *
 */
public class TransactionAccount extends BankAccount {
	
	private final static double TRANSACTION_FEE = 5.0;
	public final static int FREE_TRANSACTIONS = 4;
	private int counter;
	/**
	 * This constructor take initial balance and id as parameter.
	 * @param initialBalance The initial balance of the account.
	 * @param id The id of the bank account.
	 */
	public TransactionAccount(double initialBalance, String id) {
		super(initialBalance, id);
		counter = 0;
	}
	/**
	 * This method calculate the balance if deposit.
	 * @param amount Get the amount from user.
	 */
	@Override
	 public void deposit(double amount)
	 {  
	        super.deposit(amount);
	        counter++;
	 }
	/**
	 * This method calculate the balance if withdraw.
	 * @param amount Get the amount from user.
	 */
	 @Override
	 public void withdraw(double amount)
	 {   
	       super.withdraw(amount);
	       counter++;
	 }
	 /**
	  * This method calculate the balance in end of month.
	  */
	 @Override
	 public void endOfMonth()
	 {
		 if (counter > FREE_TRANSACTIONS)
		 {
			 super.withdraw((counter - 4) * TRANSACTION_FEE);
		 }
	 }
	 

}
