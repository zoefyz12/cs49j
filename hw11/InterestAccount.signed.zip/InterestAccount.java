
/**
 * This is a subclass of BankAccount and the owner of the account can deposit or withdraw money at any point. 
 * @author Fangyi Zhao
 *
 */
public class InterestAccount extends BankAccount {
	
private static final double INTEREST = 0.00075;
	/**
	 * This constructor take initial balance and id as parameter.
	 * @param initialBalance The initial balance of the account.
	 * @param id The id of the bank account.
	 */
	public InterestAccount(double initialBalance, String id) 
	{
		super(initialBalance, id);
	}
	/**
	  * This method calculate the balance in end of month.
	  */
	 @Override
	public void endOfMonth()
	{
		super.deposit(super.getBalance() * INTEREST);
	}

}
