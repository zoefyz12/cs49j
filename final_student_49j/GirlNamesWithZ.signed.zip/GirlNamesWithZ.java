

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GirlNamesWithZ
{
    public static void main(String[] args) throws FileNotFoundException
    {
       String filename = "babynames2000s.txt"; 
       String line;
       String[] lineOfText;
       
		File inputFile = new File(filename);
		Scanner in = new Scanner(inputFile);
		
		line = in.nextLine();
		line = in.nextLine();
		
		while (in.hasNextLine())
		{
			line = in.nextLine();
			lineOfText = line.split("\\s+");
			
			if (lineOfText[3].contains("z") || lineOfText[3].contains("Z"))
					System.out.println(lineOfText[3]);
		}
    }
}

