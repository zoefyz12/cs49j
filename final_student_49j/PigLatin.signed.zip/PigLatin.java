

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class PigLatin
{

   public static void main(String[] args)
   {
		if (args.length < 1)
		{
			System.out.println("Usage: java PigLatin infile");
			return;
		}
	   
		String s;
		File inputFile = new File(args[0]);
		
		try (Scanner in = new Scanner(inputFile);)
		{
			while (in.hasNext())
			{
				s = in.next();
				
				System.out.println(s.substring(1, s.length()) + s.substring(0, 1) + "ay");
			}
		}
		catch (FileNotFoundException e)
		{
	    	  System.out.println("No such file: " + args[0]);
		}
   }
}

