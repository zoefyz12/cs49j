

public class Car extends Product{

	private String color;
	
	public Car(String theDescription, double thePrice, String color) {
		super(theDescription, thePrice);

		this.color = color;
	}

	public String getColor() 
	{
		return color;
	}
	
	public boolean isPrimaryColor()
	{
		if (color.equalsIgnoreCase("blue") || color.equalsIgnoreCase("red") || color.equalsIgnoreCase("yellow"))
			return true;
		else
			return false;
	}
	
	public String getDescription() 
	{
		return super.getDescription() + " " + color;
	}
	
}
