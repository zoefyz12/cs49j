

import java.util.TreeSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeMap;
public class WordLengthFinder
{
   public static void main(String[] args)
   {
       String passage = "mary had a little lamb";  
       Map<Integer, TreeSet<String>> hash= new HashMap<Integer, TreeSet<String>>();
       String word;
       
       Scanner scan = new Scanner(passage);
       scan.useDelimiter("[^A-Za-z0-9]+");
		
       while (scan.hasNext()) 
		{         
			word = scan.next();
				
			if (hash.containsKey(word.length()))
			{
				TreeSet<String> s = hash.get(word.length());
				s.add(word);
				hash.put(word.length(), s);
			}
			else
			{
				TreeSet<String> list = new TreeSet<String>();
				list.add(word);
				hash.put(word.length(), list);
			}	
		}	
		
       SortedSet<Integer> keys = new TreeSet<Integer>(hash.keySet());
		
		for (Integer key : keys) { 
			TreeSet<String> value = hash.get(key);
			
			System.out.println(value);
		}
       
   }
}
