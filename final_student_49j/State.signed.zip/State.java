

/**
 * Models a US state with name and population
 */
public class State 
{
    private String name;
    private int population;
    
    /**
     * Constructs a State with name and population
     * @param stateName name of this state
     * @param thePopulation population of this state
     */
    public State(String stateName, int thePopulation)
    {
        name = stateName;
        population = thePopulation;
    }
    
    /**
     * Gets the state name
     * @return     the name of the state
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Gets the state population
     * @return the population of the state
     */
    public int getPopulation()
    {
        return population;
    }   
    
    public boolean equals(Object otherObject)
    {
      if (otherObject == null)
        return false;
      if (this.getClass() != otherObject.getClass())
        return false;
      State other = (State)otherObject;
      return (name == other.getName() && population == other.getPopulation());
    } 
    
    public String toString()
    {
    	
    	return "State[name=" + name + ",population=" + population + "]";
    }
}
