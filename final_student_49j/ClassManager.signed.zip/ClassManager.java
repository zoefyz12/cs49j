

import java.util.ArrayList;
import java.util.Collections;

public class ClassManager {

	ArrayList<String> studentName;
	
	public ClassManager()
	{
		studentName  = new ArrayList<String>();
	}
	
	
	public void enroll(String name) 
	{
		studentName.add(name);
	}
	
	public void sort() 
	{
		Collections.sort(studentName);
	}
	public double averageLength()
	{
		double total = 0;
		
		if (studentName.isEmpty())
			return 0;
		
		for (int i = 0; i < studentName.size(); i++)
		{
			total += studentName.get(i).length();
		}
		
		return total / studentName.size();
	}
	
	public String getNames()
	{
		String names = "";
		
		for (int i = 0; i < studentName.size(); i++)
		{
			names += studentName.get(i) + " ";
		}
		
		return names;
	}
}
