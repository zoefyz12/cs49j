

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class ComparingToddlers
{

   public static void main(String[] args)
   {
      Toddler[] kids = {
            new Toddler("Anwen", 42.0, 47),
            new Toddler("Taran", 36.0, 40),
            new Toddler("Jose", 36.0, 50),           
            new Toddler("Jaime", 40.5, 39),
            new Toddler("Jaime", 40.5, 42),
            new Toddler("Yasmin", 36.0, 41) };

      ArrayList <Toddler>  p = new ArrayList<Toddler>();
      
      for (int i = 0; i < kids.length; i ++)
    	  p.add(kids[i]);
      
      Collections.sort(p, new ByWeight());
      
      System.out.println("**Sort by weight");
      for(Toddler c1 : p)
    	  System.out.println(c1.getName());
      
      Collections.sort(p, new ByHeight());
      
      System.out.println("**Sort by height");
      for(Toddler c1 : p)
    	  System.out.println(c1.getName());
   }
}

class ByWeight implements Comparator<Toddler>{
	@Override
	public int compare(Toddler o1, Toddler o2) {
		return Double.compare(o1.getWeight(), o2.getWeight());
	}
}

class ByHeight implements Comparator<Toddler>{
	@Override
	public int compare(Toddler o1, Toddler o2) {
		return Double.compare(o1.getHeight(), o2.getHeight());
	}
}

