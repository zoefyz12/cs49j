

import java.util.Scanner;

public class InputProcessing {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		double douValue;
		String input;
		boolean quit = true;
		double min = 0;
		double total = 0;
		int counter = 0;
		String intString = "";
		
		System.out.print("Enter a double or Q to quit: ");
		input = scan.next();
		
		if (input.equalsIgnoreCase("Q") || !isDouble(input))
		{
			quit = false;
			System.out.println("no input");
		}
		else
		{
			douValue = Double.parseDouble(input);
			
			if (douValue % 1.0 == 0.0)
			{
				intString += String.valueOf(douValue);
			}
			
			min = douValue;
			if (douValue > 0)
			{
				total += douValue;
				counter++;
			}
		}
		
		while (quit)
		{
			System.out.print("Enter a double or Q to quit: ");
			
			input = scan.next();
			
			if (input.equalsIgnoreCase("Q") || !isDouble(input))
			{
				quit = false;
				
				System.out.println(intString);
				System.out.println(min);
				
				if (total == 0)
					System.out.println(0);
				else
					System.out.println(total / counter);
			}
			else
			{
				douValue = Double.parseDouble(input);
				
				if (douValue % 1 == 0.0)
				{
					if (intString == "")
						intString += String.valueOf(douValue);
					else
						intString += ", " + String.valueOf(douValue);
				}
				
				if (min > douValue)
					min = douValue;
				if (douValue > 0)
				{
					total += douValue;
					counter++;
				}
			}
		}
	}
	
	public static boolean isDouble(String str)
	{
        try 
        {
            Double.parseDouble(str);
            return true;
        }
        catch (NumberFormatException e) 
        {
            return false;
        }
    }

}
