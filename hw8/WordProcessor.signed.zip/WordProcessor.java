
/**
 * WordProcessor is a class which can manage an array of Strings.
 * @author Fangyi Zhao
 *
 */
public class WordProcessor {

	static final int INITIAL_CAPACITY = 8;
	
	private String[] word;
	/**
	 * WordProcessor is a constructor takes no parameters but initializes the array
	 * which the size is 8. 
	 */
	public WordProcessor()
	{
		word = new String[INITIAL_CAPACITY];
	}
	/**
	 * The add method adds the given string at the end of the partially filled array.
	 * @param toAdd The string which needed to add to the array.
	 */
	public void add(String toAdd)
	{
		growIfNeeded();
		int counter = 0;
		
		while (word[counter] != null)
		{
			counter++;
		}
		
		word[counter] = toAdd;
	}
	/**
	 * This method adds the String at the specified index.
	 * @param toAdd This parameter take the string which needed to add to the array.
	 * @param index This parameter get the position where needed to insert.
	 */
	public void add(String toAdd, int index)
	{
		growIfNeeded();
		String tem1 = word[index];
		String tem2;
		word[index] = toAdd;
		for (int i = index; i < word.length - 1; i ++)
		{
			tem2 = word[i + 1];
			word[i + 1] = tem1;
			tem1 = tem2;
		}
	}
	/**
	 * This method is remove the elements at adjacent indexes are equal.
	 */
	public void removeAdjacentDuplicates()
	{
		String tem = word[0];
		String tem1;
		
		for (int i = 1; i < word.length; i ++)
		{
			if (word[i] == null)
				return;
			
			if (tem == word[i])
			{
				for (int j = i; j < word.length - 1; j++)
				{
					word[j] = word[j + 1];
				}
				
				word[word.length - 1] = null;
				i--;
			}
			else 
			{
				tem = word[i];
			}
		}
	}
	/**
	 * This method is checks to see if the array is full. 
	 * If it is, it doubles the size of the array and copies the elements to a the new array in the same order.
	 */
	private void growIfNeeded()
	{
		boolean isFull = true;
		
		for (int i = 0; i < word.length; i++)
		{
			if (word[i] == null)
				isFull = false;
		}
		
		if (isFull)
		{
			String[] tem = new String[word.length * 2];
			
			for (int i = 0; i < word.length; i++)
			{
				tem[i] = word[i];
			}
			
			word = tem;
		}
	}
	/**
	 * This method is chance the element of the array to string to help output.
	 * @return Returns a string representation of the array. 
	 */
	public String toString()
	{
		String j = "[" + word[0];
		
		for (int i = 1; i < word.length; i++)
		{
			if (word[i] == null)
				return j + "]";
			
			j += ", " + word[i];
		}
		
		return j + "]";
	}
}
