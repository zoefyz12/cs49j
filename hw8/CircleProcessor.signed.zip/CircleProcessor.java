/**
 * This is a class named CircleProcessor which manages an array of Circles. 
 * @author Fangyi Zhao
 *
 */
public class CircleProcessor {
	
	private Circle[] circles;
	/**
	 * This is the constructor that takes an array of Circles.
	 * @param circles The name of the array from the Circles.
	 */
	public CircleProcessor(Circle[] circles)
	{
		this.circles = circles;
	}
	/**
	 * This is the method that returns the average area of the Circles in the array.
	 * @return Return the average area of the whole array.
	 */
    public double averageArea()
    {
    	double area = 0;
    	for (int i=0; i < circles.length; i++)
    	{
    		area = area + circles[i].area();
    	}
    	return area / circles.length;
    }
    /**
     * This method named swapMaxAndMin which swaps the largest and smallest elements in the array.
     */
    public void swapMaxAndMin()
    {
    	int max = 0;
    	int min = 0;
    	Circle object;
    	/**
    	 * Use the for loop to find the min and max value of the array.
    	 */
    	for (int i = 1; i < circles.length; i++)
    	{
    		if (circles[max].area() < circles[i].area())
    		{
    			max = i;
    		}
    		
    		if (circles[min].area() > circles[i].area())
    		{
    			min = i;
    		}
    	}
    	/**
    	 * Then switch the min and max.
    	 */
    	object = circles[max];
    	circles[max] = circles[min];
    	circles[min] = object;
    }
    /**
     * This method named toString that returns the string representation of the underlying array.
     * @return Return the transfered string value in the array with the frame.
     */
    public String toString()
    {
    	String i = "[" + circles[0].toString();
    	
    	for (int j = 1; j < circles.length; j++)
    		i += ", " + circles[j].toString();
    	
    	return i + "]";
    }
}
