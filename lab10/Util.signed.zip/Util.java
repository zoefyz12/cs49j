

import java.util.ArrayList;
/**
 * This class has several static methods to work with arrays and ArrayLists.
 * @author Fangyi Zhao
 *
 */
public class Util {
/**
 *This method gets the minimum value in the array.
 * @param array The array with the integer parameter.
 * @return Return the minimum integer.
 */
	public static int min(int[] array)
	{
		int mini = array[0];
		for(int i = 1; i < array.length; i++)
		{
			if (mini > array[i])
			{
				mini = array[i];
			}
		}
		return mini;
	}
	/**
	 * This method determines if the array contains a word that starts with the given letter. 
	 * Returns true if it does, otherwise returns false. 
	 * @param array Get the string array as parameter.
	 * @param letter Get the string letter as parameter.
	 * @return Return true or false.
	 */
	public static boolean contains(String[] array, String letter)
	{          
		for (int i = 0; i < array.length; i++)
		{
			if (letter.equalsIgnoreCase(array[i].substring(0, 1)))
			{
				return true;
			}
			
		}
		return false;
	}
	/**
	 * This method gets an ArrayList of all the strings in the given ArrayList that contain with the given letter.
	 * @param list Get the string type of array list as parameter.
	 * @param letter Get the character letter as parameter.
	 * @return Return the string type of array list which called newlist.
	 */
	public static ArrayList<String> contains(ArrayList<String> list, char letter)
	{
		String l = Character.toString(letter);
		ArrayList<String> newlist = new ArrayList<String>();
		for (String w: list)
		{
			if (w.contains(l.toLowerCase()) || w.contains(l.toUpperCase()))
			{
				newlist.add(w);		
			}
		}
		return newlist;		
		
	}
}
