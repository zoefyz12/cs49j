

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
/**
 * This class model a traffic light that can cycle through colors, red, green, yellow.
 * @author Fangyi Zhao
 *
 */
public class TrafficLight {

	private int x;
	private int y;
	public static final int RED = 0;
	public static final int YELLOW = 1;
	public static final int GREEN = 2;
	public static int state;
	/**
	 * The constructor takes the x,y coordinates of the upper 
	 * left hand corner of the TrafficLight as parameters and also sets the state of the light to red.
	 * @param x Get the coordinate of the left corner of x as parameter.
	 * @param y Get the coordinate of the left corner of y as parameter.
	 */
	public TrafficLight(int x, int y)
	{
		this.x = x;
		this.y = y;
		state = RED;
	}
	/**
	 * This method changes the state (the color) in the following manner.
	 */
	public void cycle()
	{
		if (state == RED)
		{
			state = GREEN;
		}
		else if (state == GREEN)
		{
			state = YELLOW;
		}
		else if (state == YELLOW)
		{
			state = RED;
		}
	}
	/**
	 * This method gets the color (the current state) of the light as a string "red", "green" or "yellow".
	 * @return The current state of type string has been returned.
	 */
	public String getLight()
	{
		String currentState = "";
		if (state == RED)
		{
			currentState = "red";
		}
		else if (state == GREEN)
		{
			currentState = "green";
		}
		else if (state == YELLOW)
		{
			currentState = "yellow";
		}
		return currentState;
	}
	/**
	 * This method draws the traffic light and fills the circles with a different color when the light is on or off. 
	 * @param g2 The format that can be draw.
	 */
	public void draw(Graphics2D g2)
	{
		g2.setColor(Color.BLACK);
		Rectangle box = new Rectangle(x, y, 20, 60);
		g2.draw(box);
		/**
		 * Determined if the state is red. If it is, make the red light on.
		 */
		if (state == RED)
		{
			g2.setColor(Color.RED);
			Ellipse2D.Double cir1 = new Ellipse2D.Double(x, y, 20, 20);
			g2.fill(cir1);
			g2.setColor(new Color(255,165,00));
			Ellipse2D.Double cir2 = new Ellipse2D.Double(x, y+20, 20, 20);
			g2.fill(cir2);
			g2.setColor(new Color(85,107,47));
			Ellipse2D.Double cir3 = new Ellipse2D.Double(x, y+40, 20, 20);
			g2.fill(cir3);
			g2.setColor(Color.BLACK);
		}
		/**
		 * Determined if the state is green. If it is, make the green light on.
		 */
		else if (state == GREEN)
		{
			g2.setColor(new Color(128,00,00));
			Ellipse2D.Double cir1 = new Ellipse2D.Double(x, y, 20, 20);
			g2.fill(cir1);
			g2.setColor(new Color(255,165,00));
			Ellipse2D.Double cir2 = new Ellipse2D.Double(x, y+20, 20, 20);
			g2.fill(cir2);
			g2.setColor(Color.GREEN);
			Ellipse2D.Double cir3 = new Ellipse2D.Double(x, y+40, 20, 20);
			g2.fill(cir3);
			g2.setColor(Color.BLACK);
		}
		/**
		 * Determined if the state is yellow. If it is, make the yellow light on.
		 */
		else if (state == YELLOW)
		{
			g2.setColor(new Color(128,00,00));
			Ellipse2D.Double cir1 = new Ellipse2D.Double(x, y, 20, 20);
			g2.fill(cir1);
			g2.setColor(Color.YELLOW);
			Ellipse2D.Double cir2 = new Ellipse2D.Double(x, y+20, 20, 20);
			g2.fill(cir2);
			g2.setColor(new Color(85,107,47));
			Ellipse2D.Double cir3 = new Ellipse2D.Double(x, y+40, 20, 20);
			g2.fill(cir3);
			g2.setColor(Color.BLACK);
		}
	}
}
