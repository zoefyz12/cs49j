

import java.util.ArrayList;
/**
 * This class uses an ArrayList to keep track of BankAccount objects. 
 * @author Fangyi Zhao
 *
 */
public class Bank {
	private ArrayList<BankAccount> bank;
	/**
	 * This constructor that takes no parameters but initialize the ArrayList bank used to collect bankAccounts.
	 */
	public Bank()
	{
		bank = new ArrayList<BankAccount>();
	}
	/**
	 * This method adds the specified BankAccount to the Bank.
	 * @param b Get the object of bankAccount which called b as parameter.
	 */
	public void add(BankAccount b)
	{
		bank.add(b);
	}
	/**
	 * This method puts the BankAccount with the largest balance first in the list. 
	 * @return  Return the ArrayList of BankAccount which called bank.
	 */
	public ArrayList<BankAccount> largestFirst ()
	{
		
		if (bank.size() == 0)
		{
			return null;
		}
		double largest = bank.get(0).getBalance();
		int j = 0;
		for (BankAccount b : bank)
		{
			if (largest < b.getBalance())
			{
				largest = b.getBalance();
				j = bank.indexOf(b);
			}
		}
		BankAccount lar = bank.get(j);
		bank.remove(j);
		bank.add(0, lar);
		return bank;
	}
	/**
	 *This method gets an ArrayList of the BankAccount accountIds in the Bank
	 * @return The new list which called id has been returned.
	 */
	public ArrayList<String> list ()
	{
		ArrayList<String> id = new ArrayList<String>();
		for (BankAccount b: bank)
		{
			id.add(b.getAccountId());
		}
		return id;
	}
	/**
	 * This method gets an ArrayList of the BankAccount accountIds 
	 * in the Bank that have balances over the specified amount.
	 * @param i Get an integer i as parameter.
	 * @return The string type of ArrayList has been returned.
	 */
	public ArrayList<String> list (int i)
	{
		ArrayList<String> l = new ArrayList<String>();
		for (BankAccount b: bank)
		{
			if (b.getBalance() > i)
			{
				l.add(b.getAccountId());
			}
		}
		return l;
	}
	/**
	 * This method determines if a BankAccount with a given accountId is in the Bank. 
	 * Return true is so, otherwise false
	 * @param c Get the string which called c as a parameter.
	 * @return Return true or false.
	 */
	public boolean contains (String c)
	{
		for (BankAccount b : bank)
		{
			if (b.getAccountId().contains(c))
			{
				return true;
			}
		}
		return false;
	}

}
