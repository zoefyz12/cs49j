

/**
 * 
 * Models a train running on a straight track going either direction 
 * @author Fangyi Zhao
 *
 */

public class SuburbanTrain {

	private int track;
	
	/**
	 * Construct a default constructor of the suburban train object to make sure the 
	 * track start from zero.
	 */
	
	public SuburbanTrain()
	{
		track = 0;
	}
	
	/**
	 * Get the distance from train to start.
	 * @return the absolute value of the track which is the distance to start.
	 */
	
	public int distanceToStart() {
		return Math.abs(track);
	}

	/**
	 * Get the distance from train to end.
	 * @return the distance from train to end which use 50 minus 
	 * the absolute value of the track.
	 */
	
	public int distanceToEnd() {
		return 50 - Math.abs(track);
	}

	/**
	 * Get the track of the train by the given number of stops.
	 * @param numberOfStops times 5 to calculate the track.
	 */
	
	public void move(int numberOfStops) 
	{
		track += numberOfStops * 5;
	}

	/**
	 * Reverses the direction of the train.
	 */
	
	public void turn() 
	{
		track *= -1;
	}

}
