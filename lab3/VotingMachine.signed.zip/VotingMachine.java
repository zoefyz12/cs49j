
/**
 * Models a voting machine.
 * @author Fangyi Zhao
 *
 */

public class VotingMachine 
{
	private int yes, no;
	
	/**
	 * Initialize two variable in the Construct VotingMachine which are yes and no.
	 */
	
	public VotingMachine()
	{
		yes  = 0;
		no = 0;
	}
	
	/**
	 * Plus one to the total yes votes if getting the yes votes.
	 */
	
	public void voteYes()
	{
		yes++;
	}
	
	/**
	 * Plus one to the total no votes if getting the no votes.
	 */
	
	public void voteNo()
	{
		no++;
	}
	
	/**
	 * Get the number of the yes votes of this voting machine.
	 * @return the number of the yes votes of this voting machine
	 */
	
	public int getYesVotes()
	{
		return yes;
	}
	
	/**
	 * Get the number of the no votes of this voting machine.
	 * @return the number of the no votes of this voting machine
	 */
	
	public int getNoVotes()
	{
		return no;
	}
}
