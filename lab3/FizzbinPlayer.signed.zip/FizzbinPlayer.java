

/**
 * Models a player of the game Fizzbin
 * @author Fangyi Zhao
 *
 */

public class FizzbinPlayer {

	private String name;
	private int adjustmentValue;
	
	/**
	 * Construct of FizzbinPlayer with the given name and adjustment value.
	 * @param name The name of this product.
	 * @param adjustmentValue The adjustment value of this product.
	 */
	
	public FizzbinPlayer(String name, int  adjustmentValue) 
	{
		this.name = name;
		this.adjustmentValue = adjustmentValue;
	}

	/**
	 * Get the name of this product.
	 * @return the name of this product
	 */
	
	public String getName()
	{
		return name;
	}
	
	/**
	 * Get the adjustment value of this product.
	 * @return the adjustment value of this product
	 */
	
	public int getAdjustment()
	{
		return adjustmentValue;
	}
	
	/**
	 * Set the a value to the adjustment value by the given value.
	 * @param value is set to adjustment value
	 */
	
	public void setAdjustment(int value)
	{
		adjustmentValue = value;
	}
}

