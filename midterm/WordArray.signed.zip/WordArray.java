

public class WordArray {

	private String[] wordArray;
	
	public WordArray(String[] arr)
	{
		wordArray = arr;
	}

	public String beginnings()
	{
		String firstThree = "";
		
		for (int i = 0; i < wordArray.length; i++)
		{
			if (wordArray[i].length() < 4)
				firstThree += wordArray[i] + " ";
			else
				firstThree += wordArray[i].substring(0, 3) + " ";
		}
		
		return firstThree;
	}
}
