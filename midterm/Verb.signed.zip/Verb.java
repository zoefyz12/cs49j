

/**
 * Models an English verb
 * @author kathleenobrien
 *
 */
public class Verb
{
   private String verb;
   
   /**
    * Constructs a new Verb with the given parameter
    * @param theVerb the verb for this Verb
    */
   public Verb(String theVerb)
   {
      verb = theVerb;
   }
   
   /**
    * Gets the verb for this object
    * @return the verb for this object
    */
   public String getVerb()
   {
      return verb;
   }
   
   /**
    * Gets the gerund for this Verb
    * @return the  gerund of this Verb
    */
   public String getGerund()
   {
      String gerund;
      
      if (verb.endsWith("e"))
      {
    	  gerund = verb.substring(0, verb.length() - 1) + "ing";
      }
      else if (verb.length() == 3 && !(verb.endsWith("a") || verb.endsWith("e") || verb.endsWith("i") || verb.endsWith("o") || verb.endsWith("u") || verb.endsWith("y")))
      {
    	  gerund = verb + verb.charAt(verb.length() - 1) + "ing";
      }
      else 
    	  gerund = verb + "ing";
      
      return gerund;
   }
}

