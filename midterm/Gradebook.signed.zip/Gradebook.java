

import java.util.ArrayList;

public class Gradebook {

	ArrayList<Student> grade;
	
	public Gradebook()
	{
		grade = new ArrayList<Student>();
	}
	
	public void add(Student s)
	{
		grade.add(s);
	}
	
	public double getClassAverage()
	{
		double totalScore = 0;
		
		if (grade.size() == 0)
			return 0;
		else
		{
			for (int i = 0; i < grade.size(); i++)
			{
				totalScore += grade.get(i).getAverage();
			}
			
			return totalScore / grade.size();
		}
	}
}
