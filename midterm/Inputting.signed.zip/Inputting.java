

import java.util.Scanner;

public class Inputting {

	public static void main(String[] args) {
		
		String input;
		double doubleInput;
		int intInput;
		Scanner sc = new Scanner(System.in);
		
		
		System.out.print("Enter your favorite dessert: ");
		input = sc.nextLine();
		
		if (input.equalsIgnoreCase("ice cream"))
			System.out.println("Delicious");
		else if (input.equalsIgnoreCase("chocolate cake"))
			System.out.println("Yummy");
		else
			System.out.println("All sugar is good");
		
		System.out.print("Enter a double: ");
		doubleInput = sc.nextDouble();
		
		System.out.print("Enter an integer: ");
		intInput = sc.nextInt();
		
		double result = doubleInput * intInput;
		
		System.out.println(result);
		
		if (result > 0)
			System.out.println("That's a positive");
		else if (result < 0)
			System.out.println("What a minus");
		else
			System.out.println("That's nothing");

	}

}
