

public class Weather {

	private double[][] tem;
	
	public Weather(double[][] array)
	{
		tem = array;
	}
	
	public int countFreezing()
	{
		int freezing = 0;
		
		for (int i = 0; i < tem.length; i++)
		{
			for (int j = 0; j < tem[0].length; j++)
			{
				if (tem[i][j] < 32)
					freezing++;
			}
		}
		
		return freezing;
	}
}
